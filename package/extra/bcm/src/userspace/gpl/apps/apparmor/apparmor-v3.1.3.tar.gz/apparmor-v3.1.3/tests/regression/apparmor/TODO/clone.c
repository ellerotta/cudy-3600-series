/* create clone testprogram */
