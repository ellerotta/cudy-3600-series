/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 *
 * This file may be redistributed under the terms of the
 * GNU Lesser General Public License.
 **/
#ifndef UTIL_LINUX_C_STRTOD_H
#define UTIL_LINUX_C_STRTOD_H

extern double c_strtod(char const *str, char **end);

#endif
