# Fuzzers

This directory contains fuzzers that
target [llvm's LibFuzzer](https://llvm.org/docs/LibFuzzer.html). They are built
and run automatically by
Google's [OSS-Fuzz](https://github.com/google/oss-fuzz/) infrastructure.
