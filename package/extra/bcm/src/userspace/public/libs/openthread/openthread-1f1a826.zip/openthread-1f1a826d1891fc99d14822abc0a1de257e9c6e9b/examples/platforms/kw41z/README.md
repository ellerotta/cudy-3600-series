The OpenThread on KW41Z example has moved to https://github.com/openthread/ot-kw41z
