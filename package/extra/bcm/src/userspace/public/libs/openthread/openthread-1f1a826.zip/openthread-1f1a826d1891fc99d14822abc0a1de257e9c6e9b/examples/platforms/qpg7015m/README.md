The OpenThread on QPG7015m example has moved to https://github.com/openthread/ot-qorvo
