The OpenThread on QPG6095 example has moved to https://github.com/openthread/ot-qorvo
