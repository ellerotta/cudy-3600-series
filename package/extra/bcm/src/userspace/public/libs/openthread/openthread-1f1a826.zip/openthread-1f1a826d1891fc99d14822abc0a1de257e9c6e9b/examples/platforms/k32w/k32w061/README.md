The OpenThread on K32W061 example has moved to https://github.com/openthread/ot-nxp
