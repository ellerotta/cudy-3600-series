The OpenThread on nRF528xx example has moved to https://github.com/openthread/ot-nrf528xx
