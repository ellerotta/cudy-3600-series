The OpenThread on SAMR21 example has moved to https://github.com/openthread/ot-samr21
