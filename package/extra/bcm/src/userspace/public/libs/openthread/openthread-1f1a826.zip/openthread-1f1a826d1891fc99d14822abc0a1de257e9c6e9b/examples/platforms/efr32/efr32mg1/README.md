The OpenThread on EFR32 example has moved to https://github.com/openthread/ot-efr32
