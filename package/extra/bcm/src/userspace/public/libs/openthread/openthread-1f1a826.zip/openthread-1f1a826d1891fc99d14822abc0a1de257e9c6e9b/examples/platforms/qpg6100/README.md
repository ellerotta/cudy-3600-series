The OpenThread on QPG6100 example has moved to https://github.com/openthread/ot-qorvo
