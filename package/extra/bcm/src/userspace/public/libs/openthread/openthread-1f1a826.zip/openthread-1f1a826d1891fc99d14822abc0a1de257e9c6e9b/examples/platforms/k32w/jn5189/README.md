The OpenThread on JN5189 example has moved to https://github.com/openthread/ot-nxp
