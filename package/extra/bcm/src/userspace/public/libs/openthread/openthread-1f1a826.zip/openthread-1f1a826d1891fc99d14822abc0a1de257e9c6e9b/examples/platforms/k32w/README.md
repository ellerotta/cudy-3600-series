The OpenThread on K32W example has moved to https://github.com/openthread/ot-nxp
