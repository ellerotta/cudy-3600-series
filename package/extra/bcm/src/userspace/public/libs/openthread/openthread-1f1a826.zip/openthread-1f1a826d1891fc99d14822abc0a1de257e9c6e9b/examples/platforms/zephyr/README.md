The OpenThread stack is integrated with ZephyrOS and nRF Connect SDK.

See the [Zephyr's OpenThread platform](https://github.com/zephyrproject-rtos/zephyr/tree/main/modules/openthread) and [CLI example](https://github.com/nrfconnect/sdk-nrf/tree/main/samples/openthread/cli) for more information about the integration.
