The OpenThread on GP712 example has moved to https://github.com/openthread/ot-qorvo
