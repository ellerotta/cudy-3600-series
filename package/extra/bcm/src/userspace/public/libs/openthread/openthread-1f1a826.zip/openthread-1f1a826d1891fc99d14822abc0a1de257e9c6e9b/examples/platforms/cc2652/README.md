The OpenThread on CC2652 example has moved to https://github.com/openthread/ot-cc13x2-cc26x2
