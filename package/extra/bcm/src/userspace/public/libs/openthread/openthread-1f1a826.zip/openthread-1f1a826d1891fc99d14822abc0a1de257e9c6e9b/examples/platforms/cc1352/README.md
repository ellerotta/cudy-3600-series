The OpenThread on CC1352 example has moved to https://github.com/openthread/ot-cc13x2-cc26x2
