The OpenThread on CC2538 example has moved to https://github.com/openthread/ot-cc2538
